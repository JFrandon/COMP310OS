#ifndef INTERPRETERH
#define INTERPRETERH

int interpreter(int, char* []);

#endif