#ifndef SHELLMEMH
#define SHELLMEMH

int setvar(char*name , char*value);
char* getvar(char* name);

#endif