#ifndef SHELLH
#define SHELLH

int parse(char* ui);


#endif